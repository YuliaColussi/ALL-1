1. Reprendre l'exercice sur les Orcs

2. À partir du fichier `Orcs.js`, créer 4 modules js contenant respectivement les 4 classes concernées.

Chacun de ces modules devront **exporter par défaut** leur classe.

3. Créer un fichier `index.js` et `index.html`

4. Dans le HTML, faire appel au fichier principal `index.js` (avec le type "module")

5. Dans `index.js`, importer les 4 classes et placer ensuite le code de l'invocation
