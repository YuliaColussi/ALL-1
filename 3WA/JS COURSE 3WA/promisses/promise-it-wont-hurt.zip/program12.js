// necessite d'installer q-io  > npm install q-io --save
var http = require('q-io/http')
http.read('http://localhost:1337')
    .then(response => console.log(JSON.parse(response)))
    .catch(console.log);