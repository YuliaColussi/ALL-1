// necessite d'installer q-io  > npm install q-io --save
var http = require('q-io/http');

http.read(`http://localhost:7000`)
    .then(id => http.read(`http://localhost:7001/${id}`))
    .then(response => console.log(JSON.parse(response)))
    .catch(console.log);
