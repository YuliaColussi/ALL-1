var promise = new Promise(function(fulfill, reject) {
    // Votre solution ici
    fulfill(`J'AI ETE APPELEE`)
    reject(new Error(`JE N'AI PAS ETE APPELEE`));
});

function onRejected(error) {
    // Votre solution ici
    console.log(error.message)
}

// Votre solution ici
promise.then(console.log, onRejected);