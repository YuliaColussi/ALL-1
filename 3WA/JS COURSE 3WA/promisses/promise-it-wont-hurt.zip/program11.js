function all(promise1, promise2) {
    let counter = 0;
    let tab = [];
   
    return new Promise((resolve) => {
        promise1.then(function (result) {
            tab[0] = result;
            counter++
            if(counter == 2) {
                resolve(tab)
            }
        })
 
        promise2.then(function (result) {
            tab[1] = result;
            counter++
            if(counter == 2) {
                resolve(tab)
            }
        })
    })
 }
 
 all(getPromise1(), getPromise2()).then(console.log)