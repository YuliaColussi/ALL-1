var promise = new Promise(function (fulfill, reject) {
    // Votre solution ici
    setTimeout(() => reject(new Error('REJET !')), 300);
  });

  function onReject(error) {
      // Votre solution ici
      console.log(error.message)
  }

// Votre solution ici
promise.then(console.log, onReject);