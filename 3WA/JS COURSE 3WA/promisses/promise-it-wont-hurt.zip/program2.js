'use strict';

var promise = new Promise(function(resolve, reject) {
  // Votre solution ici
  setTimeout(() => { resolve('ACCOMPLIE !') }, 300);
});

// Votre solution ici
promise.then(message => console.log(message) );