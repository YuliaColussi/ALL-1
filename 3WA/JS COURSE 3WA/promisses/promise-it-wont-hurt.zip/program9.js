function parsePromised() {
    return new Promise(function(fulfill, reject) {
        try {
            fulfill(JSON.parse(process.argv[2]));
        } catch(error) {
            reject(error.message.replace('SyntaxError:', ''));
        }
    });
}

parsePromised().then(null,console.log);