var promise = new Promise(function (fulfill, reject) {
    // Votre solution ici
    fulfill(`VALEUR DE LA PROMESSE`)
});

// Votre solution ici
promise.then(console.log);
console.log(`PROGRAMME PRINCIPAL`)