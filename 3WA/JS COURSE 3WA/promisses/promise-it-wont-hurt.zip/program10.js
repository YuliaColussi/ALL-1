function alwaysThrows() {
    throw new Error(`OH NOES`);
}
function iterate(num) {
    console.log(num);
    return ++num;
}
   

   
Promise.resolve(iterate(1)) // 1 
    .then(iterate)          // 2 
    .then(iterate)          // 3
    .then(iterate)          // 4
    .then(iterate)          // 5
    .then(alwaysThrows)
    .then(iterate)      // 6, mais on y passe pas on est tombé dans le catch avant 
    .then(iterate)      // 7, mais on y passe pas on est tombé dans le catch avant 
    .then(iterate)      // 8, mais on y passe pas on est tombé dans le catch avant 
    .then(iterate)      // 9, mais on y passe pas on est tombé dans le catch avant 
    .then(iterate)      // 10, mais on y passe pas on est tombé dans le catch avant 
    .catch((error) => console.log(error.message));