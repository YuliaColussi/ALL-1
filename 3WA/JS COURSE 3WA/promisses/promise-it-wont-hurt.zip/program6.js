/**
 * Attention ce code ne passe pas en FR sur promise-it-wont-hurt
 * promise-it-wont-hurt, modifier la langue en anglais pour valider l'exercice 6
 *
 * Accédez au fichier C:\Users\[]NOM DE VOTRE COMPTE UTILISATEUR\.config\promise-it-wont-hurt\lang.json
 * remplacez le contenu : {"selected":"fr"} par : {"selected":"en"}
 * relancer promise-it-wont-hurt, il sera en anglais vous pouvez valider l'exercice 6 et rebasculez 
 * en fr pensez à relancer promise-it-wont-hurt pour l'avoir en francais.
 */

var promise1 = Promise.resolve('OK');
promise1.then(console.log);

var promise = Promise.reject(new Error('OUPS la boulette'));

promise.catch((error) => console.log(error.message));

