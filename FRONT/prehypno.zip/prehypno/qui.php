<?php require_once 'inc/header.inc.php' ?>
<?php require_once 'inc/footer.inc.php' ?>