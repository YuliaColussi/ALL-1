<?php require_once 'inc/header.inc.php' ?>

<section class="container">
    <div class="row">
        <!-- PP de la Thérapeute -->
        <div class="col-md-3 mt-4 ml-6 first-margin">
            <a href="prez.php?page=prez" title="qui suis-je ?"><img src="img/pp.png"
                    class="img-thumbnail rounded-circle" alt="photo profil"></a>
        </div><!-- Fin col-md-2 -->


        <div class="col-md-6 mt-5">

            <!-- Tittre -->
            <h2 class="mt-2 mb-5">Qu'est-ce que l'hypnose ?</h2>

            <!-- Premier paragraphe -->
            <p>Did you ever had a problem with stress or have you ever wanted to quit smoking, but have always failed?</p>
            <p>What if you just let me help you?</p>
            <p class="line-end"> Anne-Cécile ROUGIER <br> Hypno-thérapeute</p>
            <button type="button" class="btn btn-info ml-3 mt-5">Vous voulez savoir plus?</button>
        </div>
        <!-- LES AVANTAGES -->
        <section class="container">
        <div class="row">
        <div class="col-md-3 ml-5">
            <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="img/articles.jpg" alt="Card image cap">
            <div class="card-body">
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div>
        </div>
        <div class="col-md-3 ml-5">
            <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="img/articles.jpg" alt="Card image cap">
            <div class="card-body">
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div>
        </div>
        <div class="col-md-3 ml-5">
            <div class="card" style="width: 18rem;">
            <img class="card-img-top" src="img/articles.jpg" alt="Card image cap">
            <div class="card-body">
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
</div>
        </div>
        </div>
</section>
<!-- MES SERVICES -->

      <section class="container">
        <div class="row">
        <div class="col-md-6">
        <h2>Пример заголовка <span class="badge badge-secondary mb-4">New</span></h2>
        <h4>Пример заголовка <span class="badge badge-secondary mb-4">New</span></h4>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
        <h4>Пример заголовка <span class="badge badge-secondary mb-4">New</span></h4>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
        <h4>Пример заголовка <span class="badge badge-secondary mb-4">New</span></h4>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
        </div>

        <div class="col-md-4">
        <img src="img/8285aca3-f163-46e0-be6a-3824252cd603 (1).jpg" style="width: 27rem; height: 38rem;" alt="">
        </div>

        </div>
</section>




<?php require_once 'inc/footer.inc.php' ?>