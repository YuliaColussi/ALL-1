// alert('okay jQ');
$(function () {

    $('#datetimepicker13').datetimepicker({
        inline: true,
        sideBySide: true
    });
});